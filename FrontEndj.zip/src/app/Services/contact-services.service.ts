import { Injectable } from '@angular/core';
import { Contact } from '../Model/contact';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContactServicesService {


  
  urlContact = '  https://localhost:44359/api/Contacts';

  constructor(private http: HttpClient) { }

   getAllContact(): Observable<Contact[]> {
    return this.http.get<Contact[]>(this.urlContact);

   }
    getContactById(contactId: string): Observable<Contact> {
      return this.http.get<Contact>(this.urlContact + '/' + contactId);
    }
    CreateContact(contact: Contact): Observable<Contact> {
      contact.CountryId=1;
      const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
      return this.http.post<Contact>(this.urlContact, contact, httpOptions);
    }
  
    updateContact(contact: Contact): Observable<Contact> {
      alert("Update")
      const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
      return this.http.put<Contact>(this.urlContact, contact, httpOptions);
    }
  
    deleteContactByContactId(contactid: string): Observable<number> {
      const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
      return this.http.delete<number>(this.urlContact + '/' + contactid, httpOptions);
    }
  
}
