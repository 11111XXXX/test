import { TestBed } from '@angular/core/testing';

import { ContactServicesService } from './contact-services.service';

describe('ContactServicesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ContactServicesService = TestBed.get(ContactServicesService);
    expect(service).toBeTruthy();
  });
});
