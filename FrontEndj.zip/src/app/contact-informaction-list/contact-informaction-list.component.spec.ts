import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactInformactionListComponent } from './contact-informaction-list.component';

describe('ContactInformactionListComponent', () => {
  let component: ContactInformactionListComponent;
  let fixture: ComponentFixture<ContactInformactionListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContactInformactionListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactInformactionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
