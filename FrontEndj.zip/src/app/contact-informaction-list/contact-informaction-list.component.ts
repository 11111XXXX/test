import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact-informaction-list',
  templateUrl: './contact-informaction-list.component.html',
  styleUrls: ['./contact-informaction-list.component.css']
})
export class ContactInformactionListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
