
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { Contact } from '../Model/contact';
import { ContactServicesService } from '../Services/contact-services.service';




@Component({
  selector: 'app-contact-info',
  templateUrl: './contact-info.component.html',
  styleUrls: ['./contact-info.component.css']
})




export class ContactInfoComponent implements OnInit {
  dataSaved = false;
  contactForm: any;
  allContact: Observable<Contact[]>;
  contactIdUpdate = null;
  massage = null;

  constructor(private formbulider: FormBuilder, private contactService: ContactServicesService) { }

  ngOnInit() {
    this.contactForm = this.formbulider.group({
      Name: ['', [Validators.required]],
     /// Country: ['', [Validators.required]],
      Email: ['', [Validators.required]],
      Mobile: ['', [Validators.required]],
      Address: ['', [Validators.required]],
      Tel: ['', [Validators.required]],   
    });
    this.loadAllContact();
  }
  loadAllContact() {
    this.allContact = this.contactService.getAllContact();
    console.log(this.allContact.source)
  }
  onFormSubmit() {
    this.dataSaved = false;
    const contact = this.contactForm.value;
    this.CreateContact(contact);
    this.contactForm.reset();
  }
  loadContactToEdit(contactId: string) {
    
    this.contactService.getContactById(contactId).subscribe(contact => {
      this.massage = null;
      this.dataSaved = false;

      console.log("contact1111")
      console.log(contact)  
     console.log("contact1111")
      this.contactIdUpdate = contact.ContactId;
      this.contactForm.controls['Name'].setValue(contact.name);
      ///this.contactForm.controls['Country'].setValue(contact.Country);
      this.contactForm.controls['Email'].setValue(contact.email);
      this.contactForm.controls['Mobile'].setValue(contact.mobile);
      this.contactForm.controls['Tel'].setValue(contact.tel);
      this.contactForm.controls['Address'].setValue(contact.address); 
      
      
      
    });

  }
  CreateContact(contact: Contact) {
    if (this.contactIdUpdate == null) {
      this.contactService.CreateContact(contact).subscribe(
        () => {
          this.dataSaved = true;
          this.massage = 'Record saved Successfully';
          this.loadAllContact();
          this.contactIdUpdate = null;
          this.contactForm.reset();
        }
      );
    } else {
      contact.ContactId = this.contactIdUpdate;
      this.contactService.updateContact(contact).subscribe(() => {
        this.dataSaved = true;
        this.massage = 'Record Updated Successfully';
        this.loadAllContact();
        this.contactIdUpdate = null;
        this.contactForm.reset();
      });
    }
  }
 
  deleteContact(contactId: string) {
    if (confirm("Are you sure you want to delete this ?")) {  
    this.contactService.deleteContactByContactId(contactId).subscribe(() => {
      this.dataSaved = true;
      this.massage = 'Record Deleted Succefully';
      this.loadAllContact();
      this.contactIdUpdate = null;
      this.contactForm.reset();

    });
  }
}
  resetForm() {
    this.contactForm.reset();
    this.massage = null;
    this.dataSaved = false;
  }
}
