// import { BrowserModule } from '@angular/platform-browser';
// import { NgModule } from '@angular/core';

// import { AppRoutingModule } from './app-routing.module';
// import { AppComponent } from './app.component';
// import { ContactInfoComponent } from './contact-info/contact-info.component';
// import { ContactInformactionListComponent } from './contact-informaction-list/contact-informaction-list.component';
// import { Routes } from '@angular/router';

// const routes: Routes = [
//   { path: '', redirectTo: '/Contact Informaction', pathMatch: 'full' },
//   { path: 'Contact Informaction', component: ContactInfoComponent },


// ];
// @NgModule({
//   declarations: [
//     AppComponent,
//     ContactInfoComponent,
//     ContactInformactionListComponent
//   ],
//   imports: [
//     BrowserModule,
//     AppRoutingModule
//   ],
//   providers: [],
//   bootstrap: [AppComponent]
// })
// export class AppModule { }



import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import {
  MatButtonModule, MatMenuModule, MatDatepickerModule, MatNativeDateModule , MatIconModule, MatCardModule, MatSidenavModule, MatFormFieldModule,
  MatInputModule, MatTooltipModule, MatToolbarModule
} from '@angular/material';
import { MatRadioModule } from '@angular/material/radio';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Routes } from '@angular/router';
import { ContactInfoComponent } from './contact-info/contact-info.component';
import { ContactInformactionListComponent } from './contact-informaction-list/contact-informaction-list.component';
import { ContactServicesService } from './Services/contact-services.service';


const routes: Routes = [
  { path: '', redirectTo: '/Contact Informaction', pathMatch: 'full' },
  { path: 'Contact Informaction', component: ContactInfoComponent },


];



@NgModule({
  declarations: [
    AppComponent,  
    ContactInfoComponent,
    ContactInformactionListComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatMenuModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatRadioModule,
    MatCardModule,
    MatSidenavModule,
    MatFormFieldModule,
    MatInputModule,
    MatTooltipModule,
    MatToolbarModule,
    AppRoutingModule
  ],
  providers: [HttpClientModule, ContactServicesService,MatDatepickerModule],
  bootstrap: [AppComponent]
})
export class AppModule { }

