export class Contact {
    // EmpId: string;
    // EmpName: string;
    // DateOfBirth: Date;
    // EmailId: string;
    // Gender: string;
    // Address: string;
    // PinCode: string;

        ContactId :number;
        Name :string;
        Address:string;
        Tel:string;
        Mobile :string;
        CountryId :number;
        Country :string;
        Email :string;
}
