﻿using System;
using System.Collections.Generic;

namespace ContactInfoRepository.Entity
{
    public partial class Countries
    {
        public Countries()
        {
            Contacts = new HashSet<Contacts>();
        }

        public int CountryId { get; set; }
        public string Country { get; set; }

        public virtual ICollection<Contacts> Contacts { get; set; }
    }
}
