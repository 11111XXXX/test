﻿using ContactInfoRepository.Entity;
using ContactInfoRepository.Repository.Contact;
using ContactInfoRepository.Repository.ExceptionHandling;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ContactInfoRepository.Repository.Country
{
  public  class CounrtyRepository: ICountryRepository
    {
        private readonly ContactInfoDatabaseContext _context;

        public CounrtyRepository(ContactInfoDatabaseContext context)
        {
            _context = context;
        }

        public async Task<List<Countries>> GetCountries()
        {
            return await _context.Countries.ToListAsync();
        }

        public async Task<Countries> GetCountry(int id)
        {
            var country = await _context.Countries.FindAsync(id);
            if (country == null)
            {
                throw new NotFoundException("Country Id Not Fount");
            }

            return country;
        }
    }
}
