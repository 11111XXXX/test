﻿using ContactInfoRepository.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ContactInfoRepository.Repository.Country
{
   public interface ICountryRepository
    {
        Task<List<Countries>> GetCountries();

        Task<Countries> GetCountry(int id);
     
        
    }
}
