﻿using ContactInfoRepository.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ContactInfoRepository.Repository.Contact
{
   public interface IContactRepository
    {


        Task<List<Contacts>> GetContacts();


        Task<Contacts> GetContacts(int id);


        Task<Contacts> PutContacts(int id, Contacts contacts);


        Task<Contacts> PostContacts(Contacts contacts);


        Task<bool> DeleteContacts(int id);
       
        
    }
}
