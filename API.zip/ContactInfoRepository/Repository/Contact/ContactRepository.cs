﻿using ContactInfoRepository.Entity;
using ContactInfoRepository.Repository.ExceptionHandling;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactInfoRepository.Repository.Contact
{
    public class ContactRepository: IContactRepository
    {
        private readonly ContactInfoDatabaseContext _context;

        public ContactRepository(ContactInfoDatabaseContext context)
        {
            _context = context;
        }

        public async Task<List<Contacts>> GetContacts()
        {
            return await _context.Contacts.ToListAsync();
        }

        public async Task<Contacts> GetContacts(int id)
        {
            var contacts = await _context.Contacts.FindAsync(id);
            if (contacts == null)
            {
                throw new NotFoundException("ContactId Not Fount");
            }

            return contacts;
        }

        public async Task<Contacts> PutContacts(int id, Contacts contacts)
        {
            if (id != contacts.ContactId)
            {
                throw new NotFoundException("ContactId Not Fount");
            }

            _context.Entry(contacts).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ContactsExists(id))
                {
                    throw new NotFoundException("ContactId Not Fount");
                }
                else
                {
                    throw;
                }
            }


            return contacts;
        }

        public async Task<Contacts> PostContacts(Contacts contacts)
        {
            _context.Contacts.Add(contacts);
            var val = await _context.SaveChangesAsync();
            if (val == 0)
            {
                throw new NotFoundException("ContactId Not Fount");
            }
            return contacts;



        }

        public async Task<bool> DeleteContacts(int id)
        {
            var contacts = await _context.Contacts.FindAsync(id);
            if (contacts == null)
            {
                throw new NotFoundException("ContactId Not Fount");
            }

            var val= _context.Contacts.Remove(contacts);
            await _context.SaveChangesAsync(true);

            return true;
        }

        private bool ContactsExists(int id)
        {
            return _context.Contacts.Any(e => e.ContactId == id);
        }
    }
}

