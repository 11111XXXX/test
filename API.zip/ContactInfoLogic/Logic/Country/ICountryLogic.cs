﻿using ContactInfoLogic.Dto.Country;
using ContactInfoRepository.Repository.Country;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ContactInfoLogic.Logic.Country
{
   public interface ICountryLogic
    {
      
        
        Task<CountryDto> GetCountry(int countryId);
       
    }
}
