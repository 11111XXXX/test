﻿using ContactInfoLogic.Dto.Country;
using ContactInfoRepository.Entity;
using ContactInfoRepository.Repository.Country;
using System.Threading.Tasks;

namespace ContactInfoLogic.Logic.Country
{


    public class CountryLogic: ICountryLogic
    {

        private readonly ICountryRepository _countryRepository;

        public CountryLogic(ICountryRepository countryRepository)
        {

            _countryRepository = countryRepository;

        }



        public async Task<CountryDto> GetCountry(int countryId)
        {
            var val = await _countryRepository.GetCountry(countryId);
            return this.GstCountryDto(val);

        }


        private CountryDto GstCountryDto(Countries country)
        {
            CountryDto dt = new CountryDto();
            dt.Country = country.Country;
            dt.CountryId = country.CountryId;
            return dt;
        }
    }
}
