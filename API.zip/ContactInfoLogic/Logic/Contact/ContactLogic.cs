﻿using ContactInfoLogic.Dto.Contact;
using ContactInfoLogic.Logic.Country;
using ContactInfoRepository.Entity;
using ContactInfoRepository.Repository.Contact;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ContactInfoLogic.Logic.Contact
{
    public class ContactLogic:IContactLogic
    {
       private readonly IContactRepository _contactRepository;
        private readonly ICountryLogic _countryLogic;

        public ContactLogic
            (
           IContactRepository contactRepository , ICountryLogic countryLogic
            )
        {
            this._contactRepository = contactRepository;
            this._countryLogic = countryLogic;

        }

        public async Task<List<ContactDto>> GetContacts()
        {

            var val = await _contactRepository.GetContacts();

            List<ContactDto> contactList = new List<ContactDto>();
            foreach (var item in val)
            {

                contactList.Add(this.GstContactDto(item));
            }

            foreach (var contact in contactList)
            {
                var valCountry = await _countryLogic.GetCountry(contact.CountryId);
                contact.Country = (valCountry.Country == null || valCountry.Country ==string.Empty ? "SL": valCountry.Country) ;
            }

            return contactList;
        }


        public async Task<ContactDto> GetContacts(int id)
        {
            var contacts = await _contactRepository.GetContacts(id);
            if (contacts == null)
            {
                //// throw new NotFoundException("ContactId Not Fount");
            }

            return this.GstContactDto(contacts);
        }


        public async Task<ContactDto> PostContacts(ContactDto contact)
        {
            var val = await _contactRepository.PostContacts(this.GstContactDto(contact));
            return GstContactDto(val); ;
        }



        public async Task<ContactDto> PutContacts(int id, ContactDto contact)
        {
            var val = await _contactRepository.PutContacts(id, this.GstContactDto(contact));
            return GstContactDto(val); ;
        }


        public async Task<bool> DeleteContacts(int id)
        {
            var val = await _contactRepository.DeleteContacts(id);
            return (val); ;
        }

        #region Private Methords
        private ContactDto GstContactDto(Contacts contacts)
        {
            ContactDto dt = new ContactDto();
            dt.ContactId = contacts.ContactId;
            dt.Name = contacts.Name;
            dt.Address = contacts.Address;
            dt.Tel = contacts.Tel;
            dt.Mobile = contacts.Mobile;
             dt.Email = contacts.Email;
            dt.CountryId = contacts.CountryId;

            return dt;
        }

        private Contacts GstContactDto(ContactDto contacts)
        {
            Contacts dt = new Contacts();
            dt.ContactId = contacts.ContactId;
            dt.Name = contacts.Name;
            dt.Address = contacts.Address;
            dt.Tel = contacts.Tel;
            dt.Mobile = contacts.Mobile;
            dt.Email = contacts.Email;
            dt.CountryId = contacts.CountryId;

            return dt;
        }

        #endregion End Private Methords


    }
}
