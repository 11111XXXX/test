﻿using ContactInfoLogic.Dto.Contact;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ContactInfoLogic.Logic.Contact
{
  public  interface IContactLogic
    {


        Task<List<ContactDto>> GetContacts();

        Task<ContactDto> GetContacts(int id);

        Task<ContactDto> PostContacts(ContactDto contact);

        Task<ContactDto> PutContacts(int id, ContactDto contact);

        Task<bool> DeleteContacts(int id);

    }
}