﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ContactInfoLogic.Dto.Country
{
   public class CountryDto
    {
        public int CountryId { get; set; }
        public string Country { get; set; }
    }
}
