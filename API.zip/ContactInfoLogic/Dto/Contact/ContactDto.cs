﻿namespace ContactInfoLogic.Dto.Contact
{
    public class ContactDto
    {
        public int ContactId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Tel { get; set; }
        public string Mobile { get; set; }
        public int CountryId { get; set; }
        public string Country { get; set; }
        public string Email { get; set; }


  
    }
}
