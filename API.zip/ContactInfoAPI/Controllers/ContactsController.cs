﻿using ContactInfoAPI.JsonDto;
using ContactInfoLogic.Dto.Contact;
using ContactInfoLogic.Logic.Contact;
using ContactInfoRepository.Entity;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ContactInfoAPI.Controllers
{
    [Produces("application/json")]
    [Route("api/[controller]")]
   
    public class ContactsController : Controller
    {
      

        private readonly IContactLogic _contactLogic;

        public ContactsController ( 
           IContactLogic contactLogic
            )
        {
            
            this._contactLogic = contactLogic;
        }

        // GET: api/Contacts
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ContactDto>>> GetContacts()
        {

            
            return await _contactLogic.GetContacts();
        }

       
        [HttpGet("{id}")]      
        public async Task<ActionResult<ContactDto>> GetContactDetailsById(int id)
        {
            var contacts = await _contactLogic.GetContacts(id);

            if (contacts == null)
            {
                return NotFound();
            }

            return contacts;
        }


        [HttpPut]
        public async Task<ActionResult<ContactDto>> PutContacts([FromBody]ContactDto contactDto)
        {
            int id = contactDto.ContactId;
            var contacts = await _contactLogic.PutContacts(id, contactDto);

            if (contacts == null)
            {
                return NotFound();
            }

            return contacts;
        }


        [HttpPost]
        public async Task<IActionResult> PostContacts([FromBody]ContactDto contactDto)
        {
            var contacts = await _contactLogic.PostContacts(contactDto);
            if (contacts == null)
            {
                return NotFound();
            }
            return CreatedAtAction("GetContacts", new { id = contacts.ContactId }, contacts);
        }








        // DELETE: api/Contacts/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<bool>> DeleteContacts(int id)
        {
            var contacts = await _contactLogic.DeleteContacts(id);

            return contacts;
        }

        //private bool ContactsExists(int id)
        //{
        //    return _context.Contacts.Any(e => e.ContactId == id);
        //}
    }
}
